<style type="text/css">
<!--
.style1 {
	color: #000000;
	font-weight: bold;
}
-->
</style>
 <div class="footer">
          <div class="style1"> <p> All Rights Reserved. &copy; 2022  Designed By : University of Juba  </p>
</div>
</div>
