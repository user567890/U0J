<li class="nav-header">
                    
                    <div class="logo-element">
                        IN+
                    </div>
                </li>
                <li class="active">
                <a href="index.php"><i class="fa fa-th-large"></i> <span class="nav-label">Dashboard</span></a></li>
				<li>
                    <a href="#"><i class="fa fa-user"></i> <span class="nav-label">Profile</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse">
                        <li><a href="profile.php">View Profile</a></li>
					  <li><a href="edit-profile.php">Edit Profile</a></li>
  					
                    </ul>
                </li>
			
				<li>
                    <a href="chkadmission.php"><i class="fa fa-money"></i> <span class="nav-label">Get Admission Letter</span></a>
                </li>
			