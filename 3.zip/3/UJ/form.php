

						<form role="form" class="form-horizontal" method= "POST" action="">
							<div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" id="email1" placeholder="PIN number" type="text" name="txtpin" required>
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" id="exampleInputPassword1" placeholder="Serial Number" type="text" name="txtserial" required>
								</div>
							</div>
							<div class="row">
								<div class="col-sm-10">
									<button type="submit" name="btnsubmit" class="btn btn-light btn-radius btn-brd grd1">Continue >></button>
								</div>
							</div>
						</form>
