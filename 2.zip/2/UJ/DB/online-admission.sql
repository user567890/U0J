-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 24, 2023 at 01:30 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online-admission`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `ID` int(4) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`ID`, `username`, `password`) VALUES
(1, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `admission`
--

CREATE TABLE `admission` (
  `ID` int(3) NOT NULL,
  `pro` varchar(45) NOT NULL,
  `fullname` varchar(45) NOT NULL,
  `typeofcertificate` varchar(40) NOT NULL,
  `certificateyear` varchar(12) NOT NULL,
  `gradeobtained` varchar(30) NOT NULL,
  `school` varchar(30) NOT NULL,
  `s_indexno` varchar(30) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `states` varchar(30) NOT NULL,
  `telephoneno1` varchar(15) NOT NULL,
  `telephoneno2` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `kingname` varchar(60) NOT NULL,
  `kingno` varchar(44) NOT NULL,
  `college` varchar(44) NOT NULL,
  `dept` varchar(44) NOT NULL,
  `certificate_copy` varchar(200) NOT NULL,
  `statuss` varchar(44) NOT NULL,
  `nationality_copy` varchar(200) NOT NULL,
  `date_admission` varchar(22) NOT NULL,
  `applicationID` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admission`
--

INSERT INTO `admission` (`ID`, `pro`, `fullname`, `typeofcertificate`, `certificateyear`, `gradeobtained`, `school`, `s_indexno`, `gender`, `dob`, `states`, `telephoneno1`, `telephoneno2`, `email`, `kingname`, `kingno`, `college`, `dept`, `certificate_copy`, `statuss`, `nationality_copy`, `date_admission`, `applicationID`) VALUES
(7, 'Diploma', 'Kafinger Adam ', 'SSCSEE', '2020', '73%', 'YDSS', '000043', 'Male', '0000-00-00', 'South Kordufan', '0916936636', '0923535368', 'kafingeradam@gmail.edu', 'Adam Kude', '0980020142', 'COMPUTER SCIENCE AND IT', 'INFORMATION TECHNOLOGY', 'upload/waec.jpeg', '1', 'upload/passport.jpeg', '12/10/2021', 'ADM/2021/56053'),
(8, 'Degree', 'Murbe thomas', 'SSCSE', '2020', '95%', 'LSS', '000653', 'Male', '0000-00-00', 'jubek', '0912345678', '0923456781', 'murbethomas@gmail.edu', 'thomas deng', '0980023456', 'ENGINEERING', 'CIVIL ENGINEERING', 'upload/default.jpg', '1', 'upload/default.jpg', '15/10/2021', 'ADM/2024/14088');

-- --------------------------------------------------------

--
-- Table structure for table `scratchcard`
--

CREATE TABLE `scratchcard` (
  `ID` int(4) NOT NULL,
  `pin` varchar(10) NOT NULL,
  `serial` varchar(10) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `scratchcard`
--

INSERT INTO `scratchcard` (`ID`, `pin`, `serial`, `status`) VALUES
(1, '7890327890', '6789332145', 1),
(2, '9877659087', '6643541231', 1),
(3, '9000988754', '0098786541', 1),
(4, '9865489076', '3214568907', 1),
(5, '5455009876', '3213436903', 0),
(6, '5567889012', '1290875444', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `admission`
--
ALTER TABLE `admission`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `scratchcard`
--
ALTER TABLE `scratchcard`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `ID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admission`
--
ALTER TABLE `admission`
  MODIFY `ID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `scratchcard`
--
ALTER TABLE `scratchcard`
  MODIFY `ID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
